void ordenacion_intercambio(int* p, int* f);
void ordenacion_seleccion(int* p, int* f);
void ordenacion_insercion(int* p, int* f);

