public class metodoMathRandom {

	public static void main(String[] args) {
	double numAleatorio;
		for (int i=0;i<100;i++){
			numAleatorio=Math.random();
			System.out.println(numAleatorio);
		}

	}
}